package dao;

public class BookingSystemRepositoryImpl {

}
