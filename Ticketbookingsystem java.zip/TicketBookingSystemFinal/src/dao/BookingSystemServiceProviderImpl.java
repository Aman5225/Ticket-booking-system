package dao;

import entity.AbstractEvent;
import entity.Booking;
import entity.Customer;
import entity.Event;     // generic Event for DB‐loaded
import entity.Venue;
import exception.EventNotFoundException;
import exception.InvalidBookingIDException;
import util.DBUtil;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class BookingSystemServiceProviderImpl
        implements IBookingSystemServiceProvider {

    private final List<AbstractEvent> events = new ArrayList<>();
    private final List<Booking>       bookings = new ArrayList<>();

    public BookingSystemServiceProviderImpl() {
        loadEventsFromDB();
    }

    private void loadEventsFromDB() {
        String sql = """
          SELECT e.event_id, e.event_name, e.event_date, e.event_time,
                 e.total_seats, e.ticket_price, e.event_type,
                 v.venue_name, v.address
            FROM events e
            JOIN venue  v ON e.venue_id = v.venue_id
        """;
        try (Connection c = DBUtil.getDBConn();
             Statement  st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                int    id     = rs.getInt("event_id");
                String name   = rs.getString("event_name");
                LocalDate d   = rs.getDate("event_date").toLocalDate();
                LocalTime t   = rs.getTime("event_time").toLocalTime();
                int    seats  = rs.getInt("total_seats");
                double price  = rs.getDouble("ticket_price");
                String type   = rs.getString("event_type");
                Venue  venue  = new Venue(
                   rs.getString("venue_name"),
                   rs.getString("address")
                );

                // we load them all as generic Event
                Event e = new Event(name, d, t, venue, seats, price, type);
                e.setEventId(id);
                events.add(e);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public List<AbstractEvent> getAllEvents() {
        // return a copy so user can't modify our list
        return new ArrayList<>(events);
    }

    @Override
    public void addEvent(AbstractEvent e) {
        // purely in‐memory
        int nextId = events.stream()
                           .mapToInt(AbstractEvent::getEventId)
                           .max().orElse(1000) + 1;
        e.setEventId(nextId);
        events.add(e);
    }

    @Override
    public Booking bookTicket(Customer c,
                              int eventId,
                              int numTickets)
            throws EventNotFoundException {
        AbstractEvent found = events.stream()
            .filter(e -> e.getEventId() == eventId)
            .findFirst()
            .orElse(null);
        if (found == null)
            throw new EventNotFoundException(
                "Event ID " + eventId + " not found."
            );
        Booking b = new Booking(c, found, numTickets);
        bookings.add(b);
        return b;
    }

    @Override
    public Booking getBookingById(int bookingId)
            throws InvalidBookingIDException {
        return bookings.stream()
            .filter(b -> b.getBookingId() == bookingId)
            .findFirst()
            .orElseThrow(() ->
                new InvalidBookingIDException(
                    "Booking ID " + bookingId + " not found."
                )
            );
    }
}


