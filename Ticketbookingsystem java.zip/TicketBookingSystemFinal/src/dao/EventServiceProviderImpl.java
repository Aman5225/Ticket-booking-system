package dao;

import entity.AbstractEvent;
import entity.Venue;
import entity.subevents.Concert;
import entity.subevents.Movie;
import entity.subevents.Sports;

import java.time.LocalDate;
import java.time.LocalTime;

public class EventServiceProviderImpl implements IEventServiceProvider {
    @Override
    public AbstractEvent createEvent(String name,
                                     String date,
                                     String time,
                                     int seats,
                                     double price,
                                     String type,
                                     Venue venue) {
        LocalDate d = LocalDate.parse(date);
        LocalTime t = LocalTime.parse(time);
        return switch(type.toLowerCase()) {
            case "movie"   -> new Movie(name,d,t,venue,seats,price,"Movie",
                                       "Action","Actor","Actress");
            case "concert" -> new Concert(name,d,t,venue,seats,price,"Concert",
                                         "Artist","Live");
            case "sports"  -> new Sports(name,d,t,venue,seats,price,"Sports",
                                        "Cricket","TeamA vs B");
            default        -> null;
        };
    }
}


