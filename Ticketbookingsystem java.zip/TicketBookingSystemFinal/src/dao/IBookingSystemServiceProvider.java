package dao;

import entity.Booking;
import entity.Customer;
import exception.EventNotFoundException;
import exception.InvalidBookingIDException;

import java.util.List;

public interface IBookingSystemServiceProvider {
    
    List<entity.AbstractEvent> getAllEvents();

    
    void addEvent(entity.AbstractEvent e);

    Booking bookTicket(Customer c, int eventId, int numTickets)
        throws EventNotFoundException;

    Booking getBookingById(int bookingId)
        throws InvalidBookingIDException;
}
