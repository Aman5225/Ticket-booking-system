package dao;

import entity.AbstractEvent;
import entity.Venue;

public interface IEventServiceProvider {
    AbstractEvent createEvent(String name,
                              String date,
                              String time,
                              int totalSeats,
                              double price,
                              String type,
                              Venue venue);
}
