package entity;

import java.time.LocalDate;
import java.time.LocalTime;

public abstract class AbstractEvent {
    private int eventId;
    private String eventName;
    private LocalDate eventDate;
    private LocalTime eventTime;
    private int totalSeats;
    private int availableSeats;
    private double ticketPrice;
    private String eventType;
    private Venue  venue;

    public AbstractEvent() { }

    public AbstractEvent(String name, LocalDate date, LocalTime time,
                         Venue venue, int seats, double price, String type) {
        this.eventName      = name;
        this.eventDate      = date;
        this.eventTime      = time;
        this.venue          = venue;
        this.totalSeats     = seats;
        this.availableSeats = seats;
        this.ticketPrice    = price;
        this.eventType      = type;
    }

   
    public int getEventId()             
    { return eventId; }
    public void setEventId(int id)        
    { this.eventId = id; }

    
    public String getEventName()        
    { return eventName; }
    public LocalDate getEventDate()    
    { return eventDate; }
    public LocalTime getEventTime()      
    { return eventTime; }
    public int getTotalSeats()         
    { return totalSeats; }
    public int getAvailableSeats()     
    { return availableSeats; }
    public double getTicketPrice()    
    { return ticketPrice; }
    public String getEventType()    
    { return eventType; }
    public Venue getVenue()           
    { return venue; }

    
    public void bookTickets(int num) {
        if (availableSeats >= num) {
            availableSeats -= num;
        } else {
            throw new IllegalArgumentException("Not enough seats available.");
        }
    }

    public abstract void displayEventDetails();
}
