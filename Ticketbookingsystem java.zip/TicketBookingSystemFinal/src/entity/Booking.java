package entity;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

public class Booking {
    private static int nextId = 5001;
    private int bookingId;
    private Set<Customer> customers;
    private AbstractEvent event;
    private int numTickets;
    private LocalDate date;

    public Booking(Customer c, AbstractEvent e, int numTickets) {
        this.bookingId  = nextId++;
        this.customers = new HashSet<>();
        this.customers.add(c);
        this.event      = e;
        this.numTickets = numTickets;
        this.date       = LocalDate.now();
        e.bookTickets(numTickets);
    }

    public int getBookingId() { return bookingId; }

    public void displayBookingDetails() {
        System.out.printf(
          "Booking [%d] %s | Tickets: %d%n",
          bookingId, date, numTickets
        );
        event.displayEventDetails();
        customers.forEach(Customer::displayCustomerDetails);
    }
}



