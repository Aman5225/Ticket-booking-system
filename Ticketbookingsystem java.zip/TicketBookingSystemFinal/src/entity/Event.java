package entity;

import java.time.LocalDate;
import java.time.LocalTime;

public class Event extends AbstractEvent {
    public Event() {}

    public Event(String eventName, LocalDate eventDate, LocalTime eventTime, Venue venue,
                 int totalSeats, double ticketPrice, String eventType) {
        super(eventName, eventDate, eventTime, venue, totalSeats, ticketPrice, eventType);
    }

    @Override
    public void displayEventDetails() {
        System.out.println("Event Name: " + getEventName());
        System.out.println("Date: " + getEventDate());
        System.out.println("Time: " + getEventTime());
        System.out.println("Type: " + getEventType());
        System.out.println("Ticket Price: ₹" + getTicketPrice());
        System.out.println("Available Seats: " + getAvailableSeats());
        getVenue().displayVenueDetails();
    }
}

