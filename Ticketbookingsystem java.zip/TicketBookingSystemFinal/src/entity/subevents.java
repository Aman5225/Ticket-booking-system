package entity;

import java.time.LocalDate;
import java.time.LocalTime;

public class subevents {
    public static class Movie extends AbstractEvent {
        private String genre, actor, actress;
        public Movie(String name, LocalDate d, LocalTime t, Venue v,
                     int seats, double price, String type,
                     String genre, String actor, String actress) {
            super(name,d,t,v,seats,price,type);
            this.genre   = genre;
            this.actor   = actor;
            this.actress = actress;
        }
        @Override
        public void displayEventDetails() {
            System.out.printf(
              "Movie [%d] %s on %s %s @ %s%n" +
              "  Genre: %s | Actor: %s | Actress: %s%n" +
              "  Seats left: %d | Price: ₹%.2f%n",
              getEventId(), getEventName(), getEventDate(), getEventTime(),
              getVenue().getVenueName(),
              genre, actor, actress,
              getAvailableSeats(), getTicketPrice()
            );
        }
    }

    public static class Concert extends AbstractEvent {
        private String artist, concertType;
        public Concert(String name, LocalDate d, LocalTime t, Venue v,
                       int seats, double price, String type,
                       String artist, String concertType) {
            super(name,d,t,v,seats,price,type);
            this.artist      = artist;
            this.concertType = concertType;
        }
        @Override
        public void displayEventDetails() {
            System.out.printf(
              "Concert [%d] %s on %s %s @ %s%n" +
              "  Artist: %s | Style: %s%n" +
              "  Seats left: %d | Price: ₹%.2f%n",
              getEventId(), getEventName(), getEventDate(), getEventTime(),
              getVenue().getVenueName(),
              artist, concertType,
              getAvailableSeats(), getTicketPrice()
            );
        }
    }

    public static class Sports extends AbstractEvent {
        private String sport, teams;
        public Sports(String name, LocalDate d, LocalTime t, Venue v,
                      int seats, double price, String type,
                      String sport, String teams) {
            super(name,d,t,v,seats,price,type);
            this.sport = sport;
            this.teams = teams;
        }
        @Override
        public void displayEventDetails() {
            System.out.printf(
              "Sports [%d] %s on %s %s @ %s%n" +
              "  Sport: %s | Teams: %s%n" +
              "  Seats left: %d | Price: ₹%.2f%n",
              getEventId(), getEventName(), getEventDate(), getEventTime(),
              getVenue().getVenueName(),
              sport, teams,
              getAvailableSeats(), getTicketPrice()
            );
        }
    }
}




