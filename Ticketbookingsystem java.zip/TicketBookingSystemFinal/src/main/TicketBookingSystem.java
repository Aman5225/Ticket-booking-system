package main;

import dao.BookingSystemServiceProviderImpl;
import dao.EventServiceProviderImpl;
import dao.IBookingSystemServiceProvider;
import dao.IEventServiceProvider;

import entity.AbstractEvent;
import entity.Booking;
import entity.Customer;
import entity.Venue;
import exception.EventNotFoundException;
import exception.InvalidBookingIDException;

import java.util.List;
import java.util.Scanner;

public class TicketBookingSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        IEventServiceProvider eventSvc = new EventServiceProviderImpl();
        IBookingSystemServiceProvider bookSvc = new BookingSystemServiceProviderImpl();

        while (true) {
            System.out.println(
                "\n--- Ticket Booking System ---\n" +
                "1. Create Event\n" +
                "2. View All Events\n" +
                "3. Book Tickets\n" +
                "4. View Booking by ID\n" +
                "5. Exit\n"
            );
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();  // consume newline

            switch (choice) {
                case 1: {
                    System.out.print("Name: ");
                    String name = sc.nextLine();
                    System.out.print("Date (yyyy-MM-dd): ");
                    String date = sc.nextLine();
                    System.out.print("Time (HH:mm): ");
                    String time = sc.nextLine();
                    System.out.print("Seats: ");
                    int seats = sc.nextInt();
                    System.out.print("Price: ");
                    double price = sc.nextDouble();
                    sc.nextLine();  // consume newline
                    System.out.print("Type (movie/concert/sports): ");
                    String type = sc.nextLine();
                    System.out.print("Venue name: ");
                    String vName = sc.nextLine();
                    System.out.print("Venue address: ");
                    String vAddr = sc.nextLine();

                    Venue venue = new Venue(vName, vAddr);
                    AbstractEvent e = eventSvc.createEvent(
                        name, date, time, seats, price, type, venue
                    );
                    if (e != null) {
                        bookSvc.addEvent(e);
                        System.out.println(
                            "Event created (in‑memory) with ID=" + e.getEventId()
                        );
                    } else {
                        System.out.println("Invalid event type.");
                    }
                    break;
                }

                case 2: {
                    List<AbstractEvent> events = bookSvc.getAllEvents();
                    if (events.isEmpty()) {
                        System.out.println("No events available.");
                    } else {
                        for (AbstractEvent ev : events) {
                            ev.displayEventDetails();
                            System.out.println("----------------------");
                        }
                    }
                    break;
                }

                case 3: {
                    System.out.print("Customer name: ");
                    String cname = sc.nextLine();
                    System.out.print("Event ID: ");
                    int eid = sc.nextInt();
                    System.out.print("Tickets: ");
                    int num = sc.nextInt();
                    sc.nextLine();  // consume newline

                    try {
                        Booking b = bookSvc.bookTicket(
                            new Customer(cname), eid, num
                        );
                        System.out.println(
                            "Booked! Your booking ID=" + b.getBookingId()
                        );
                    } catch (EventNotFoundException ex) {
                        System.out.println("Error: " + ex.getMessage());
                    }
                    break;
                }

                case 4: {
                    System.out.print("Booking ID: ");
                    int bid = sc.nextInt();
                    sc.nextLine();  // consume newline

                    try {
                        Booking b = bookSvc.getBookingById(bid);
                        b.displayBookingDetails();
                    } catch (InvalidBookingIDException ex) {
                        System.out.println("Error: " + ex.getMessage());
                    }
                    break;
                }

                case 5: {
                    System.out.println("Goodbye!");
                    sc.close();
                    return;
                }

                default: {
                    System.out.println("Invalid choice.");
                    break;
                }
            }
        }
    }
}


