package util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class DBPropertyUtil {
    public static Properties loadPropertiesFile() throws IOException {
        Properties prop = new Properties();
        try (InputStream input = DBPropertyUtil.class
                .getClassLoader()
                .getResourceAsStream("db.properties")) {
            if (input == null) {
                throw new IOException("Unable to find db.properties");
            }
            prop.load(input);
        }
        return prop;
    }
}

