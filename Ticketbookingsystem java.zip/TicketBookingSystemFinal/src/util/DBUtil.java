package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {
    public static Connection getDBConn() throws SQLException {
        try {
            Properties props = DBPropertyUtil.loadPropertiesFile();
            String url  = props.getProperty("db.url");
            String user = props.getProperty("db.username");
            String pass = props.getProperty("db.password");

            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(url, user, pass);
        } catch (Exception e) {
            throw new SQLException("Error connecting to DB: " + e.getMessage(), e);
        }
    }
}

